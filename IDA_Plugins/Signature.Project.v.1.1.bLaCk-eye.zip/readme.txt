BigLib Signature Collection 1.1

1.About:

This is a collection with most of the bignumber libraries i found on the net at the present time (1.10.2004).
It contains signature files that you can use along with IDA to recognize procedures used by a crackme or a commercial app that uses that library.
I created these .sig files using the FLAIR Package v.4.21 that comes along with IDA 4.5.1.770.

2.How to use:

Copy the signature files (*.sig) into your IDA\Sig\ directory.
When you know that a target uses a bignum library then load it (the target) in IDA,wait for the ending of the dissasembly process,then open the signatures window (Shift+F5), select Apply New Signature (INS) and then select the signature file that matches the bignumber library you know your target is using.

3.Contents of collection:

-BigLib v.0.0.e by roy.
-Miracl v.4.7.4 (from the package).
-Freelip v.1.1, available for small size options as well for speed.
-BigNumber by Q, i found this one in contest.anticrack.de solution for contest 3 by +Q
available for small size options as well for speed.
-Mpi v.0.93 - available in the LibTomCrypt crypto library,available for small size options as well for speed.
-ECCBignum - a very crude bignum library that's like an add-on for a book about ecc,available for small size options as well for speed.
-BorZoiLib - a bignum library that's present with the BorZoi ECC library,,available for small size options as well for speed.
-GiantInt - another bignum library which i found out on my HDD.Latest update of the source-code is from 11 Feb 03.
	    Later i found out it's (c) Perfectly Scientific, Inc.
-Witeg Bignum Lib - very small bignum library written by Witeg (you can get it from my site)
-FGint - a delphi bignum library with support for ECC,DSA,ElGAMAl,RSA (I got this from SlashZero - thanks)
	NOTE: FGintPackage.sig contains ALL of the other fgint sigs.
-NTL - the Number Theory Library  by Shoup, not really a bignum lib, but contains many math routines.I don't know where i got the
	sig for this one

4.History:
1.1................ added: FGint (Thanks to SlashZero), Witeg's Bignum Library, NTL by Shoup
1.0................ First release!

5.Future Plans
Add
-any other bignum library & crypto lib i can get my hands on.

6.Thanks&Contact
-Kanal23 Members
-TKM! members
-all the dudes inside #reversing4elites, you RULZ!
-Crudd

Anything related to this:
mycherynos@yahoo.com

Regards,
                                         bLaCk-eye/K23!